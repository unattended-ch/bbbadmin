<?php

namespace BigBlueButton\Exceptions;

use Exception;

class BadResponseException extends Exception
{
}
