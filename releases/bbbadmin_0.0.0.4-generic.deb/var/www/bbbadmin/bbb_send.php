<?php
//********************************************************************
//* Description: Send invitation link to user
//* Author: Automatix <github@unattended.ch>
//* Created at: Tue Aug 31 16:01:06 UTC 2021
//*
//* Copyright (c) 2021 Automatix  All rights reserved.
//*
//********************************************************************
namespace BigBlueButton;
$serverid = $_GET['sid'];
$meetingID = $_GET['mID'];
require_once('./bbb_load.php');
use BigBlueButton\BigBlueButton;
$url = 'https://room.unattended.ch?sid='.$serverid.'&mID='.$meetingID;
$empfaenger = "automatix@unattended.ch";
$betreff = "Sitzungseinladung";
$from = "From: Automatix <[automatix@unattended.ch]>";
$text = $url;
 
mail($empfaenger, $betreff, $text, $from);

?>
